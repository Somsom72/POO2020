
public class Dvd extends Produto
{
	public Dvd(int codigo, String nome)
	{
		super(codigo, nome);
	}
	
	public void imprime()
	{
		System.out.printf("Foi encontrado um DVD com:\nNome: %s\nCodigo: %d\n", this.getNome(), this.getCodigo());
	}
}
