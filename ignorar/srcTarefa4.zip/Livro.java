
public class Livro extends Produto
{
	public Livro(int codigo, String nome)
	{
		super(codigo, nome);
	}
	
	public void imprime()
	{
		System.out.printf("Foi encontrado um LIVRO com:\nNome: %s\nCodigo: %d\n", this.getNome(), this.getCodigo());
	}
}
