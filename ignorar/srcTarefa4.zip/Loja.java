import java.io.IOException;
import java.util.ArrayList;
import java.util.ListIterator;

public class Loja 
{
	static ArrayList<Produto> estoque = new ArrayList<Produto>(); // lista para armazenar produtos 
	static Produto p;
	/* armazenam quantidade de cada tipo de produto na loja */
	static int nLivros, nDvds, nCds;
	
	public static void main(String[] args) throws NumberFormatException, IOException
	{
		nLivros = nDvds = nCds = 0;
		int op = 0;
		while (op != 8) 
		{
			op = leOpcao();
			switch (op)
			{
			case 1:
				System.out.println("Digite o codigo de barras (um numero sem espacos) e o nome do novo livro, separados por ENTER.\n");
				p = new Livro(EntradaTeclado.leInt(), EntradaTeclado.leString());
				adicionaProduto(estoque, p);
				break;
			case 2:
				System.out.println("Digite o codigo de barras (um numero sem espacos) e o nome do novo DVD, separados por ENTER.\n");
				p = new Dvd(EntradaTeclado.leInt(), EntradaTeclado.leString());
				adicionaProduto(estoque, p);
				break;
			case 3:
				System.out.println("Digite o codigo de barras (um numero sem espacos) e o nome do novo CD, separados por ENTER.\n");
				p = new Cd(EntradaTeclado.leInt(), EntradaTeclado.leString());
				adicionaProduto(estoque, p);
				break;
			case 4:
				System.out.println("Digite o nome do produto buscado.\n");
				buscaNome(estoque, EntradaTeclado.leString());
				break;
			case 5:
				System.out.println("Digite o codigo do produto buscado (um numero).\n");
				buscaCodigo(estoque, EntradaTeclado.leInt());
				break;
			case 6:
				System.out.println("Digite o codigo do produto que deseja vender (um numero).\n");
				vendeProduto(estoque, EntradaTeclado.leInt());
				break;
			case 7:
				verificaEstoque();
				break;
			case 8:
				System.out.println("Terminando o programa....");
				return;
			}
		}
	}
	
	/* funcao menu */
	private static int leOpcao()
	{
	      System.out.println("1) Adicionar livro\n2) Adicionar DVD\n" + 
	    		  			"3) Adicionar CD\n4) Buscar por nome\n" +
	        				"5) Buscar por codigo\n6) Vender\n" +
	    		  			"7) Verificar estoque\n8) Sair");
	        int k = -1;
	        while(true)
	        {
	        	System.out.println("Digite a opcao desejada ===> ");
	        	try {
	        		k = EntradaTeclado.leInt();
	        		if ( k > 0 && k < 9 )
	        			return k;
	        		throw new IllegalArgumentException("Digite um numero de 1 a 8!\n");
	        	}
	        	catch (Exception e){System.out.println(e.getMessage());}
	        }
	}
	
	/* adiciona produto */
	private static void adicionaProduto(ArrayList<Produto> estoque, Produto p)
	{
		estoque.add(p);
		System.out.println("Produto adicionado!\n");
		
		/* incrementa quantidade do produto no estoque */
		if(p instanceof Livro)
		{
			nLivros++;
		}
		else if(p instanceof Dvd)
		{
			nDvds++;
		}
		else 
		{
			nCds++;
		}
	}
	
	/* remove produto */
	private static void vendeProduto(ArrayList<Produto> estoque, int codigo)
	{
		/* percorre lista ate achar chave, remove se achar, retorna se nao achar */
		ListIterator<Produto> it = estoque.listIterator();
		Produto aux;
		while(it.hasNext())
		{
			aux = it.next();
	        if(aux.getCodigo() == codigo)
	        {
	        	it.remove();
	        	/* decrementa quantidade desse produto no estoque */
	        	if(aux instanceof Livro) {nLivros--;}
	        	else if(aux instanceof Dvd) {nDvds--;}
	        	else {nCds--;}
	    		System.out.println("Produto removido!\n");
	        	return;
	        }
	    }    
		System.out.println("Produto nao encontrado!\n");
	}
	
	/* busca produto por nome */
	private static void buscaNome(ArrayList<Produto> estoque, String nome)
	{
		/* percorre lista ate achar chave e imprime a pessoa se achar, caso nao, retorna */
		ListIterator<Produto> it = estoque.listIterator();
		Produto p;
		while(it.hasNext())
		{
			p = it.next();
	        if(p.getNome().toLowerCase().equals(nome.toLowerCase()))
	        {
	        	if(p instanceof Livro)
	        	{
	        		((Livro) p).imprime();
	        	}
	        	else if(p instanceof Dvd)
	        	{
	        		((Dvd) p).imprime();
	        	}
	        	else
	        	{
	        		((Cd) p).imprime();
	        	}
	        	return;
	        }
	        System.out.println("Produto nao encontrado!\n");
	    }    
	}
	
	/* busca pessoa por codigo */
	private static void buscaCodigo(ArrayList<Produto> estoque, int codigo)
	{
		/* percorre lista ate achar chave e imprime a pessoa se achar, caso nao, retorna */
		ListIterator<Produto> it = estoque.listIterator();
		Produto p;
		while(it.hasNext())
		{
			p = it.next();
	        if(p.getCodigo() == codigo)
	        {
	        	if(p instanceof Livro)
	        	{
	        		((Livro) p).imprime();
	        	}
	        	else if(p instanceof Dvd)
	        	{
	        		((Dvd) p).imprime();
	        	}
	        	else
	        	{
	        		((Cd) p).imprime();
	        	}
	        	return;
	        }
	        System.out.println("Produto nao encontrado!\n");
	    }    
	}
	
	/* verifica estoque */
	private static void verificaEstoque()
	{
		System.out.printf("QUANTIDADES:\nLivros: %d\nDVDs: %d\nCDs: %d\n\n", nLivros, nDvds, nCds);
	}
	
}
