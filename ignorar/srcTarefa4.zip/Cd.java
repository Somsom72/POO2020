
public class Cd extends Produto 
{
	public Cd(int codigo, String nome)
	{
		super(codigo, nome);
	}
	
	public void imprime()
	{
		System.out.printf("Foi encontrado um CD com:\nNome: %s\nCodigo: %d\n", this.getNome(), this.getCodigo());
	}
}
