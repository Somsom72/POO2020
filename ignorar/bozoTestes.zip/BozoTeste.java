import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

// CLASSE DE TESTE UNIFICADA PARA O PROJETO "JOGO_BOZO"

public class BozoTeste {
	
	public Placar pl;
	public Dado dd;
	public RolaDados rldd;
	
	@Before
	public void setUp() {
		pl = new Placar();
		dd = new Dado();
		rldd = new RolaDados(5);
	}

	@After
	public void tearDown() {
		pl = null;
		dd = null;
		rldd = null;
	}

	@Test
	public void testPLACARAddGetScore1() {
		int[] vetorDados = new int[]{1,1,2,3,4}; // caso teste para posicao 1
		pl.add(1, vetorDados);
		int pontos = pl.getScore();
		
		/* confere */
		assertEquals(2, pontos);
	}
	
	@Test
	public void testPLACARAddGetScore2() {
		int[] vetorDados = new int[]{1,1,2,3,4}; // caso teste para posicao 2
		pl.add(2, vetorDados);
		int pontos = pl.getScore();
		
		/* confere */
		assertEquals(2, pontos);
	}
	
	@Test
	public void testPLACARAddGetScore3() {
		int[] vetorDados = new int[]{1,1,2,3,4}; // caso teste para posicao 3
		pl.add(3, vetorDados);
		int pontos = pl.getScore();
		
		/* confere */
		assertEquals(3, pontos);
	}
	
	@Test
	public void testPLACARAddGetScore4() {
		int[] vetorDados = new int[]{1,1,2,3,4}; // caso teste para posicao 4
		pl.add(4, vetorDados);
		int pontos = pl.getScore();
		
		/* confere */
		assertEquals(4, pontos);
	}
	
	@Test
	public void testPLACARAddGetScore5() {
		int[] vetorDados = new int[]{1,1,2,3,4}; // caso teste para posicao 5
		pl.add(5, vetorDados);
		int pontos = pl.getScore();
		
		/* confere */
		assertEquals(0, pontos);
	}
	
	@Test
	public void testPLACARAddGetScore6() {
		int[] vetorDados = new int[]{1,1,2,3,4}; // caso teste para posicao 6
		pl.add(6, vetorDados);
		int pontos = pl.getScore();
		
		/* confere */
		assertEquals(0, pontos);
	}
	
	@Test
	public void testPLACARAddGetScore7() {
		int[] vetorDados = new int[]{2,1,6,6,4}; // caso teste para posicao 7
		pl.add(7, vetorDados);
		int pontos = pl.getScore();
		
		/* confere */
		assertEquals(0, pontos);
	}
	
	@Test
	public void testPLACARAddGetScore8() {
		int[] vetorDados = new int[]{1,5,2,3,4}; // caso teste para posicao 8
		pl.add(8, vetorDados);
		int pontos = pl.getScore();
		
		/* confere */
		assertEquals(20, pontos);
	}
	
	@Test
	public void testPLACARAddGetScore9() {
		int[] vetorDados = new int[]{1,1,1,1,4}; // caso teste para posicao 9
		pl.add(9, vetorDados);
		int pontos = pl.getScore();
		
		/* confere */
		assertEquals(30, pontos);
	}
	
	@Test
	public void testPLACARAddGetScore10() {
		int[] vetorDados = new int[]{1,1,2,3,4}; // caso teste para posicao 10
		pl.add(10, vetorDados);
		int pontos = pl.getScore();
		
		/* confere */
		assertEquals(0, pontos);
	}
	
	@Test
	public void testPLACARAddToString() {
		
		int[] vetorDados = new int[]{2,3,2,3,4};
		pl.add(1, vetorDados);
		
		/* confere se a posicao1 == 0 mesmo */
		String r = "0      |   (7)    |   (4)    \r\n" + 
				"--------------------------\r\n" + 
				"(2)    |   (8)    |   (5)    \r\n" + 
				"--------------------------\r\n" + 
				"(3)    |   (9)    |   (6)    \r\n" + 
				"--------------------------\r\n" + 
				"       |   (10)   |       \r\n" + 
				"       +----------+     ";
		
		assertEquals(pl.toString(), r);
	}
	
	@Test
	public void testDADORolar() {
		/* apenas conferindo limites */
		if(dd.getLado() > 0 && dd.getLado() < 7) {
			assertEquals(1, 1);
		}
	}
	
	@Test
	public void testDADOLado() {
		
		dd.rolar(6);
		
		/* alem de testar os limites, confere se retorna o resultado consistente */
		if(dd.getLado() > 0 && dd.getLado() < 7) {
			int a = dd.getLado();
			int b = dd.getLado();
			assertEquals(a, b);
		}
		assertEquals(1, 2);
	}
	
	@Test
	public void testRolaDadosRolarInicial() {
		
		int[] vetorDados = rldd.rolar();
		
		/* itera o mesmo teste de dado para o vetor de dados */
		int i;
		int flag = 0;
		for(i = 0; i < 5; i++)
		{
			if(vetorDados[i] > 0 && vetorDados[i] < 7);
			else {flag = 1;}
		}
		assertEquals(0, flag);
	}
	
	@Test
	public void testRolaDadosReRolar1() {
		// indiretamente testa "rolar(boolean[] quais)"
		assertEquals(rldd.rolar(), rldd.rolar("")); // confere se de fato nao mudou nada na segunda rolada
	}
	
	@Test
	public void testRolaDadosReRolar2() {
		// indiretamente testa "rolar(boolean[] quais)"
		assertEquals(rldd.rolar(), rldd.rolar("1 2 3 4")[4]); // re-rola todos menos o ultimo, confere se este nao muda
	}
	
	@Test
	public void testRolaDadosToString() {
		// indiretamente testa "toStringAux"
		// impossivel testar pela forma que foi implementado o rand dentro de RolaDados
		assertEquals(1, 1);
		return;
	}
}

// Obs. 
// Classe Random nao testada individualmente pois ja e indiretamente testada nos outros testes (dado);
// Bozo nao testado pois apenas contem o metodo main;
// EntradaTeclado tambem nao, pois ja foi importada pronta e testada;

// Pelas razoes acima, os teste produzem cobertura aproximadamente 70%
