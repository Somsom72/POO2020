
public class Dado {
	
	private int nLados;
	private int ladoAtual;
	
	/* Cria um cubo */
	public Dado()
	{
		nLados = 6;
		ladoAtual = 1;
	}
	
	/* Cria um poliedro de n lados */
	/*
	public Dado(int n)
	{
		nLados = n;
		ladoAtual = 1;
	}
	*/ // OMITIDA POR DESUSO
	
	/* Atualiza o campo 'ladoAtual' */
	public int rolar(int k)
	{
		Random r = new Random(k);
		ladoAtual = r.getIntRand(nLados) + 1;
		return ladoAtual;
	}
	
	/* Retorna o campo 'ladoAtual' */
	public int getLado()
	{
		return ladoAtual;
	}
	
}