
/**  Representa uma pessoa juridica. */

public class PessoaJuridica extends Pessoa
{

	private String inscricaoEst, razaoSoc, cnpj;
	
	public PessoaJuridica(String nome, String endereco, String email, String inscricaoEst, String razaoSoc, String cnpj)
	{
		super(nome, endereco, email);
		this.inscricaoEst = inscricaoEst;
		this.razaoSoc = razaoSoc;
		this.cnpj = cnpj;
	}

	/* retorna demais campos */
	public String getInscricao(){return inscricaoEst;}
	public String getRazao(){return razaoSoc;}
	public String getCNPJ(){return cnpj;}

	/* imprime dados dessa pessoa */
	public void imprime()
	{
		System.out.println("Nome: " + this.getNome());
		System.out.println("Endereco: " + this.getEndereco());
		System.out.println("Email: " + this.getEmail());
		System.out.println("Numero de Inscricao Estadual: " + this.inscricaoEst);
		System.out.println("Razao Social: " + this.razaoSoc);
		System.out.println("CNPJ: " + this.cnpj);
	}
	
}
