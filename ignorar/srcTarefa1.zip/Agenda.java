/** Representa uma agenda de ate 1000 pessoas. */

import java.util.*; 

public class Agenda 
{
	
	public static void main(String[] args) throws Exception
	{
		ArrayList<Pessoa> agenda = new ArrayList<Pessoa>(); // lista para armazenar pessoas (fisicas ou juridicas)
		PessoaFisica pf;
		PessoaJuridica pj;
		
		int op = 0;
		while (op != 8) {
			op = leOpcao();
			switch (op)
			{
			case 1: 
				System.out.println("Insira, separados por ENTER:\n" +
									"O nome;\nO endereco;\nO email;\nO dia de nascimento (em numero, nao palavras);\n" +
									"O mes de nascimento (em numero, nao palavras);\nO ano de nascimento (em numero, nao palavras)\n" +
									"Numero 0 se solteiro(a) e 1 caso casado(a);\nO CPF (apenas um numero, sem tracos/barras/espacos/etc.);");
				pf = new PessoaFisica(EntradaTeclado.leString(), EntradaTeclado.leString(), EntradaTeclado.leString(), EntradaTeclado.leInt(), EntradaTeclado.leInt(), EntradaTeclado.leInt(), EntradaTeclado.leInt(), EntradaTeclado.leString());
				adicionaFisica(agenda, pf);
				
				break;
			case 2:
				System.out.println("Insira, separados por ENTER:\n" +
						"O nome;\nO endereco;\nO email;\nA inscricao estadual;\n" +
						"A razao social;\nO CNPJ (apenas um numero, sem tracos/barras/espacos/etc.;");
				pj = new PessoaJuridica(EntradaTeclado.leString(), EntradaTeclado.leString(), EntradaTeclado.leString(), EntradaTeclado.leString(), EntradaTeclado.leString(), EntradaTeclado.leString());
				adicionaJuridica(agenda, pj);
				break;
			case 3:
				System.out.println("Insira o exato nome da pessoa (fisica ou juridica) a ser removida.");
				removePessoa(agenda, EntradaTeclado.leString());
				break;
			case 4:
				System.out.println("Insira o exato nome da pessoa (fisica ou juridica) procurada.");
				buscaNome(agenda, EntradaTeclado.leString());
				break;
			case 5:
				System.out.println("Digite CPF ou CNPJ da pessoa desejada.");
				buscaNumero(agenda, EntradaTeclado.leString());
				break;
			case 6:
				visualizarAgenda(agenda);
				break;
			case 7:
				ordenarAgenda(agenda);
				break;
			case 8:
				System.out.println("Terminando o programa....");
				return;
			}
		}
	}
		
	/* funcao menu */
	private static int leOpcao()
	{
	      System.out.println("1) Adicionar pessoa fisica\n2) Adicionar pessoa juridica\n" + 
	    		  			"3) Remover pessoa\n4) Buscar por nome\n" +
	        				"5) Buscar por cpf ou cnpj\n6) Visualizar agenda\n" +
	    		  			"7) Ordenar agenda\n8) Sair");
	        int k = -1;
	        while(true)
	        {
	        	System.out.println("Digite a opcao desejada ===> ");
	        	try {
	        		k = EntradaTeclado.leInt();
	        		if ( k > 0 && k < 9 )
	        			return k;
	        		throw new IllegalArgumentException("Digite um numero de 1 a 8!\n");
	        	}
	        	catch (Exception e){System.out.println(e.getMessage());}
	        }
	}
	
	/* adiciona pessoa fisica */
	private static void adicionaFisica(ArrayList<Pessoa> agenda, PessoaFisica p)
	{
		agenda.add(p);
		System.out.println("Pessoa adicionada!\n");
	}
	
	/* adiciona pessoa juridica */
	private static void adicionaJuridica(ArrayList<Pessoa> agenda, PessoaJuridica p)
	{
		agenda.add(p);
		System.out.println("Pessoa adicionada!\n");
	}
	
	/* remove pessoa */
	private static void removePessoa(ArrayList<Pessoa> agenda, String nome)
	{
		/* percorre lista ate achar chave, remove se achar, retorna se nao achar */
		ListIterator<Pessoa> it = agenda.listIterator();
		while(it.hasNext())
		{
	        if(it.next().getNome().toLowerCase().equals(nome))
	        {
	        	it.remove();
	        	break;
	        }
	    }    
		System.out.println("Pessoa removida!\n");
	}
	
	/* busca pessoa por nome */
	private static void buscaNome(ArrayList<Pessoa> agenda, String nome)
	{
		/* percorre lista ate achar chave e imprime a pessoa se achar, caso nao, retorna */
		ListIterator<Pessoa> it = agenda.listIterator();
		Pessoa p;
		while(it.hasNext())
		{
			p = it.next();
	        if(p.getNome().toLowerCase().equals(nome))
	        {
	        	if(p instanceof PessoaFisica)
	        	{
	        		((PessoaFisica) p).imprime();
	        	}
	        	else
	        	{
	        		((PessoaJuridica) p).imprime();
	        	}
	        	return;
	        }
	        System.out.println("Pessoa nao encontrada!\n");
	    }    
	}
	
	/* busca pessoa por cpf/cnpj */
	private static void buscaNumero(ArrayList<Pessoa> agenda, String n)
	{
		/* percorre lista ate achar chave e imprime a pessoa se achar, caso nao, retorna */
		ListIterator<Pessoa> it = agenda.listIterator();
		Pessoa p;
		while(it.hasNext())
		{
			p = it.next();
			if(p instanceof PessoaFisica)
			{
				 if(((PessoaFisica) p).getCPF().toLowerCase().equals(n))
			        {
			        	((PessoaFisica) p).imprime();
			        	return;
			        }
			}
			else
			{
				if(((PessoaJuridica) p).getCNPJ().toLowerCase().equals(n))
		        {
		        		((PessoaJuridica) p).imprime();
		        	return;
		        }
			}
	    }    
        System.out.println("Pessoa nao encontrada!\n");
	}
	
	/* visualizar agenda */
	private static void visualizarAgenda(ArrayList<Pessoa> agenda)
	{
		/* percorre e imprime */
		ListIterator<Pessoa> it = agenda.listIterator();
		Pessoa p;
		while(it.hasNext())
		{
			p = it.next();
			if(p instanceof PessoaFisica)
			{
				((PessoaFisica) p).imprime();
			}
			else
			{
				((PessoaJuridica) p).imprime();
			}
			System.out.println("");
		}
	}
	
	/* ordenar agenda */
	private static void ordenarAgenda(ArrayList<Pessoa> agenda)
	{
		Collections.sort(agenda, new SortLegal());
		System.out.println("Agenda ordenada!\n");
	}
}

/** Determina criterio de comparacao para ordenacao da agenda. */
class SortLegal implements Comparator<Pessoa> 
{ 
	
    public int compare(Pessoa a, Pessoa b) 
    { 
    	if(a instanceof PessoaFisica && b instanceof PessoaFisica)
    	{
    		 return ((PessoaFisica) a).getCPF().compareTo(((PessoaFisica) b).getCPF()); 
    	}
    	else if(a instanceof PessoaJuridica && b instanceof PessoaJuridica)
    	{
    		return ((PessoaJuridica) a).getCNPJ().compareTo(((PessoaJuridica) b).getCNPJ()); 
    	}
    	else if(a instanceof PessoaFisica && b instanceof PessoaJuridica)
    	{
    		return -2147483647; // maximo valor de int (garantir pessoa fisica na frente)
    	}
    	else if(a instanceof PessoaJuridica && b instanceof PessoaFisica)
    	{
    		return 2147483647;
    	}
		return 0;
    } 
} 

