/** Representa uma pessoa generica. */

public class Pessoa 
{
	/* campos em comum entre pessoa fisica e juridica */
	private String nome, endereco, email;
	
	/* construtor para Pessoa */
	public Pessoa(String nome, String endereco, String email)
	{
		this.nome = nome;
		this.endereco = endereco;
		this.email = email;
	}
	
	/* retorna nome/endereco/email */
	public String getNome(){return nome;}
	public String getEndereco(){return endereco;}
	public String getEmail(){return email;}
	
}
