/** Representa uma pessoa fisica. */

public class PessoaFisica extends Pessoa
{

	private int diaNasc, mesNasc, anoNasc, estCivil;
	private String cpf;

	
	public PessoaFisica(String nome, String endereco, String email, int diaNasc, int mesNasc, int anoNasc, int estCivil, String cpf)
	{
		super(nome, endereco, email);
		this.diaNasc = diaNasc;
		this.mesNasc = mesNasc;
		this.anoNasc = anoNasc;
		this.estCivil = estCivil;
		this.cpf = cpf;
	}
	
	/* retorna demais campos */
	public int getDia(){return diaNasc;}
	public int getMes(){return mesNasc;}
	public int getAno(){return anoNasc;}
	public int getEstado(){return estCivil;}
	public String getCPF(){return cpf;}
	
	/* imprime dados dessa pessoa */
	public void imprime()
	{
		System.out.println("Nome: " + this.getNome());
		System.out.println("Endereco: " + this.getEndereco());
		System.out.println("Email: " + this.getEmail());
		System.out.printf("Data de Nascimento: %02d/%02d/%d\n", this.diaNasc, this.mesNasc, this.anoNasc);
		if(this.estCivil == 1)
		{
			System.out.println("Estado Civil: Casado(a)");
		}
		else
		{
			System.out.println("Estado Civil: Solteiro(a)");
		}
		System.out.println("CPF: " + this.cpf);
	}
	
}
