
public class Figura {
	private String cor; // nome da cor da figura
	private boolean filled; // falso indica nao preenchida, verdadeiro indica preenchida
	
	/* define construtor */
	public Figura(String cor, boolean filled)
	{
		this.cor = cor;
		this.filled = filled;
	}
	
	/* funcoes getters */
	public String getCor()
	{
		return cor;
	}
	public boolean getFilled()
	{
		return filled;
	}
	
}
