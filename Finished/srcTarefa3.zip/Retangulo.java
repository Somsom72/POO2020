
public class Retangulo extends Figura{
	
	private double altura;
	private double largura;
	
	/* define construtor */
	public Retangulo(String cor, boolean filled, double altura, double largura)
	{
		super(cor, filled);
		this.altura = altura;
		this.largura = largura;
	}
	
	/* funcoes com sobrecarga entre filhos da classe "Figura" */
	public double area()
	{
		return altura*largura;
	}
	public double perimetro()
	{
		return 2*altura + 2*largura;
	}
	
}
