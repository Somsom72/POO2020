
public class Quadrado extends Figura{

	private double lado;
	
	/* define construtor */
	public Quadrado(String cor, boolean filled, double lado)
	{
		super(cor, filled);
		this.lado = lado;
	}
	
	/* funcoes com sobrecarga entre filhos da classe "Figura" */
	public double area()
	{
		return lado*lado;
	}
	public double perimetro()
	{
		return 4*lado;
	}
	
}
