
public class Circulo extends Figura{
	
	private double raio;
	
	/* define construtor */
	public Circulo(String cor, boolean filled, double raio)
	{
		super(cor, filled);
		this.raio = raio;
	}
	
	/* funcoes com sobrecarga entre filhos da classe "Figura" */
	public double area()
	{
		return (3.14)*raio*raio;
	}
	public double perimetro()
	{
		return 2*(3.14)*raio;
	}
	
}
